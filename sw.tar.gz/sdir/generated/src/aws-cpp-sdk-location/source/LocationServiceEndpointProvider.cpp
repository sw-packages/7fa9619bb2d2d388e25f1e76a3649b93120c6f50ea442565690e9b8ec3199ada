﻿/**
 * Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * SPDX-License-Identifier: Apache-2.0.
 */

#include <aws/location/LocationServiceEndpointProvider.h>

namespace Aws
{
namespace LocationService
{
namespace Endpoint
{
} // namespace Endpoint
} // namespace LocationService
} // namespace Aws
